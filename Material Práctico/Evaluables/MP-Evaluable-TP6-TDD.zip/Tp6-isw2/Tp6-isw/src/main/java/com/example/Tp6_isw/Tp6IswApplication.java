package com.example.Tp6_isw;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Tp6IswApplication {

	public static void main(String[] args) {
		SpringApplication.run(Tp6IswApplication.class, args);
	}

}
