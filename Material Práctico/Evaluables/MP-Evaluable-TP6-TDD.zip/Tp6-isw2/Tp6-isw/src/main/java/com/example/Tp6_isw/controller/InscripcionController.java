package com.example.Tp6_isw.controller;

import com.example.Tp6_isw.controller.request.InscripcionRequest;
import com.example.Tp6_isw.controller.response.InscripcionResponse;
import com.example.Tp6_isw.service.InscripcionService;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

@Controller
@RequestMapping("/inscripcion")
public class InscripcionController {

    private final InscripcionService inscripcionService;

    public InscripcionController(InscripcionService inscripcionService) {
        this.inscripcionService = inscripcionService;
    }

    @GetMapping()
    public String mostrarFormularioDeInscripcion() {
        return "formulario-inscripcion";
    }

    @GetMapping("/nueva")
    public String mostrarNuevoFormulario() {
        // pa probar el html nuevo
        return "formulario-inscripcion2";
    }

    @PostMapping()
    public String procesarInscripcion(@ModelAttribute InscripcionRequest request, RedirectAttributes redirectAttributes) {
        InscripcionResponse response = inscripcionService.registrarInscripcion(request);
        redirectAttributes.addFlashAttribute("inscripcion", response);
        return "redirect:/inscripcion/exito";
    }

    @GetMapping("/exito")
    public String mostrarPaginaExito() {
        return "inscripcion-exitosa";
    }
}
