package com.example.Tp6_isw.controller.request;

import com.example.Tp6_isw.domain.TipoActividad;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Actividad {

    private TipoActividad tipoActividad;
    private String horario;
    private int cantidadPersonas;
    private boolean TyC;
}
