package com.example.Tp6_isw.controller.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InscripcionRequest {

    private Actividad actividad;
    private List<Visitante> visitantes;

}
