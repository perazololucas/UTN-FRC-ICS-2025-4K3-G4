package com.example.Tp6_isw.controller.request;

import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Visitante {

    private String nombreCompleto;
    private String dni;
    private Integer edad;
    private String talla;
}
