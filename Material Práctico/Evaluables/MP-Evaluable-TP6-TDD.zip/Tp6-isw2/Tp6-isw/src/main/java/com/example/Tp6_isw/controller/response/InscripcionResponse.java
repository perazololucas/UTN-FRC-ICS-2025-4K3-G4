package com.example.Tp6_isw.controller.response;

import com.example.Tp6_isw.controller.request.Actividad;
import com.example.Tp6_isw.controller.request.Visitante;
import lombok.AllArgsConstructor;
import lombok.Builder;
import lombok.Data;
import lombok.NoArgsConstructor;

import java.util.List;

@Data
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class InscripcionResponse {

    private Actividad actividad;
    private List<Visitante> visitantes;
}
