package com.example.Tp6_isw.domain;

import java.time.LocalDate;
import java.time.LocalDateTime;
import java.time.LocalTime;
import java.util.List;

public enum TipoActividad {

    SAFARI(false, 8, List.of(
            LocalDateTime.of(LocalDate.now(), LocalTime.of(9, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(9, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(11, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(11, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(12, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(12, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(13, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(13, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(14, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(14, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(15, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(15, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(16, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(16, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(17, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(17, 30))
    )),

    JARDINERIA(false, 12, List.of(
            LocalDateTime.of(LocalDate.now(), LocalTime.of(9, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(9, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(11, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(11, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(12, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(12, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(13, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(13, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(14, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(14, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(15, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(15, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(16, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(16, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(17, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(17, 30))
    )),

    PALESTRA(true, 12, List.of(
            LocalDateTime.of(LocalDate.now(), LocalTime.of(9, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(9, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(11, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(11, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(12, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(12, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(13, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(13, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(14, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(14, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(15, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(15, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(16, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(16, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(17, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(17, 30))
    )),

    TIROLESA(true, 10, List.of(
            LocalDateTime.of(LocalDate.now(), LocalTime.of(9, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(9, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(10, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(11, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(11, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(12, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(12, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(13, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(13, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(14, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(14, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(15, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(15, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(16, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(16, 30)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(17, 0)),
            LocalDateTime.of(LocalDate.now(), LocalTime.of(17, 30))
    ));

    private final boolean requiereRopaEspecial;
    private final int cuposMaximos;
    private final List<LocalDateTime> horarios;

    TipoActividad(boolean requiereRopaEspecial, int cuposMaximos, List<LocalDateTime> horarios) {
        this.requiereRopaEspecial = requiereRopaEspecial;
        this.cuposMaximos = cuposMaximos;
        this.horarios = horarios;
    }

    public boolean isRequiereRopaEspecial() {
        return requiereRopaEspecial;
    }

    public int getCuposMaximos() {
        return cuposMaximos;
    }

    public List<LocalDateTime> getHorarios() {
        return horarios;
    }
}
