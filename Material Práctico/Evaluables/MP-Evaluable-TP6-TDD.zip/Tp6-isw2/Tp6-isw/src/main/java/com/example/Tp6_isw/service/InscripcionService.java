package com.example.Tp6_isw.service;

import com.example.Tp6_isw.controller.request.Actividad;
import com.example.Tp6_isw.controller.request.InscripcionRequest;
import com.example.Tp6_isw.controller.request.Visitante;
import com.example.Tp6_isw.controller.response.InscripcionResponse;
import com.example.Tp6_isw.domain.TipoActividad;
import org.springframework.stereotype.Service;

import java.time.LocalTime;
import java.util.*;
import java.util.stream.Collectors;

@Service
public class InscripcionService {

    private final Map<TipoActividad, Map<LocalTime, Integer>> cuposOcupados = new HashMap<>();

    public InscripcionService() {
        Arrays.stream(TipoActividad.values()).forEach(tipo ->
                cuposOcupados.put(tipo, new HashMap<>())
        );
    }

    public InscripcionResponse registrarInscripcion(InscripcionRequest request) {
        validarInscripcion(request);
        return InscripcionResponse.builder()
                .actividad(request.getActividad())
                .visitantes(request.getVisitantes())
                .build();
    }

    private void validarInscripcion(InscripcionRequest request) {
        validarDatosBasicos(request.getActividad());
        validarCantidadYVisitantes(request.getActividad(), request.getVisitantes());
        validarDatosIndividualesVisitantes(request.getVisitantes());
        validarDuplicadosDNI(request.getVisitantes());
        validarReglasDeNegocio(request.getActividad(), request.getVisitantes());
    }

    private void validarDatosBasicos(Actividad actividad) {
        if (actividad.getTipoActividad() == null) {
            throw new IllegalArgumentException("Se debe seleccionar una actividad para realizar una inscripción");
        }
        if (actividad.getHorario() == null) {
            throw new IllegalArgumentException("Se debe seleccionar un horario para la actividad");
        }
        if (!actividad.isTyC()) {
            throw new IllegalArgumentException("Se deben aceptar los términos y condiciones para realizar una inscripción");
        }
    }

    private void validarCantidadYVisitantes(Actividad actividad, List<Visitante> visitantes) {
        int cantidadPersonas = actividad.getCantidadPersonas();
        if (cantidadPersonas <= 0) {
            throw new IllegalArgumentException("Se debe ingresar una cantidad correcta de personas");
        }
        if (visitantes.isEmpty()) {
            throw new IllegalArgumentException("No se puede realizar una inscripción sin visitantes");
        }
    }

    private void validarDatosIndividualesVisitantes(List<Visitante> visitantes) {
        for (Visitante v : visitantes) {
            if (v.getNombreCompleto() == null ||
                    v.getDni() == null ||
                    v.getEdad() == null) {
                throw new IllegalArgumentException("Los datos de uno o más visitantes están incompletos.");
            }
            if (!v.getNombreCompleto().matches("^[a-zA-ZáéíóúÁÉÍÓÚñÑ\\s]+$")) {
                throw new IllegalArgumentException("El nombre del visitante solo puede contener letras.");
            }
            if (!v.getDni().matches("\\d+")) {
                throw new IllegalArgumentException("El DNI del visitante solo puede contener números.");
            }
            if (v.getEdad() == 0) {
                throw new IllegalArgumentException("La edad no puede ser cero.");
            }

        }
    }

    private void validarDuplicadosDNI(List<Visitante> visitantes) {
        Set<String> dnis = visitantes.stream()
                .map(Visitante::getDni)
                .collect(Collectors.toSet());
        if (dnis.size() < visitantes.size()) {
            throw new IllegalArgumentException("No puede haber visitantes con el mismo DNI en una inscripción.");
        }
    }

    private void validarReglasDeNegocio(Actividad actividad, List<Visitante> visitantes) {
        int cantidadPersonas = actividad.getCantidadPersonas();
        TipoActividad tipoActividad = actividad.getTipoActividad();
        LocalTime horarioSeleccionado = LocalTime.parse(actividad.getHorario());

        if (cantidadPersonas > tipoActividad.getCuposMaximos()) {
            throw new IllegalArgumentException("La cantidad de visitantes supera el cupo para esta actividad");
        }

        Map<LocalTime, Integer> cuposPorHorario = cuposOcupados.get(tipoActividad);
        int ocupadosActual = cuposPorHorario.getOrDefault(horarioSeleccionado, 0);
        int nuevaCantidad = ocupadosActual + cantidadPersonas;

        if (nuevaCantidad > tipoActividad.getCuposMaximos()) {
            throw new IllegalArgumentException("No hay cupos disponibles para el horario seleccionado");
        }

        cuposPorHorario.put(horarioSeleccionado, nuevaCantidad);


        boolean horarioValido = tipoActividad.getHorarios().stream()
                .anyMatch(ldt -> ldt.toLocalTime().equals(horarioSeleccionado));
        if (!horarioValido) {
            throw new IllegalArgumentException("No se puede realizar una inscripción en el horario de cierre del parque");
        }

        boolean requiereTalle = tipoActividad.isRequiereRopaEspecial();
        if (requiereTalle) {
            boolean faltaTalle = visitantes.stream().anyMatch(v -> v.getTalla().isBlank());
            if (faltaTalle) {
                throw new IllegalArgumentException("Se debe ingresar un talle de ropa para esta actividad");
            }
        }
        if (tipoActividad == TipoActividad.TIROLESA) {
            boolean hayMenores = visitantes.stream().anyMatch(v -> v.getEdad() < 12);
            if (hayMenores) {
                throw new IllegalArgumentException("La edad mínima para la actividad de Tirolesa es de 12 años.");
            }
        }
    }
}