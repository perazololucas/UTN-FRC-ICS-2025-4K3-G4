package com.example.Tp6_isw.service;

import com.example.Tp6_isw.controller.request.Actividad;
import com.example.Tp6_isw.controller.request.InscripcionRequest;
import com.example.Tp6_isw.controller.request.Visitante;
import com.example.Tp6_isw.controller.response.InscripcionResponse;
import com.example.Tp6_isw.domain.TipoActividad;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;

import static org.junit.jupiter.api.Assertions.*;

@ExtendWith(MockitoExtension.class)
public class InscripcionServiceTest {

    @InjectMocks
    private InscripcionService service;

    private static final String HORARIO_VALIDO_SAFARI = "10:00";
    private static final String HORARIO_VALIDO_TIROLESA = "10:00";

    // --- Caso de Éxito Principal (Happy Path) ---

    @Test
    public void test_registrar_inscripcion_datos_validos() {
        List<Visitante> visitantes = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        Visitante visitante = Visitante.builder()
                .nombreCompleto("Felipe Arias")
                .dni("12345678")
                .edad(25)
                .build();
        visitantes.add(visitante);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        InscripcionResponse response = service.registrarInscripcion(request);

        assertNotNull(response);
    }

    // --- Pruebas para: validarDatosBasicos(Actividad actividad) ---

    @Test
    public void test_registrar_inscripcion_sin_actividad() {
        List<Visitante> visitantes = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();
        Visitante visitante = Visitante.builder()
                .nombreCompleto("Juan Perez")
                .dni("12345678")
                .edad(25)
                .build();
        visitantes.add(visitante);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("Se debe seleccionar una actividad para realizar una inscripción", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_sin_horario() {
        List<Visitante> visitantes = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .build();

        Visitante visitante = Visitante.builder()
                .nombreCompleto("Maria Garcia")
                .dni("12345678")
                .edad(25)
                .build();
        visitantes.add(visitante);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("Se debe seleccionar un horario para la actividad", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_no_acepta_tyc() {
        List<Visitante> visitantes = new ArrayList<>();
        visitantes.add(Visitante.builder()
                .nombreCompleto("Luis Hernandez")
                .dni("12345678")
                .edad(25)
                .build());
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(false)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();
        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("Se deben aceptar los términos y condiciones para realizar una inscripción", exception.getMessage());
    }

    // --- Pruebas para: validarCantidadYVisitantes(Actividad actividad, List<Visitante> visitantes) ---

    @Test
    public void test_registrar_inscripcion_cantidad_personas_negativa() {
        List<Visitante> visitantes = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(-1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        visitantes.add(Visitante.builder()
                .nombreCompleto("Carlos Rodriguez")
                .dni("12345678")
                .edad(25)
                .build());

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("Se debe ingresar una cantidad correcta de personas", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_sin_visitantes() {
        List<Visitante> visitantesVacios = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();
        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantesVacios)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("No se puede realizar una inscripción sin visitantes", exception.getMessage());
    }

    // --- Pruebas para: validarDatosIndividualesVisitantes(List<Visitante> visitantes) ---

    @Test
    public void test_registrar_inscripcion_datos_visitante_incompletos() {
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        Visitante visitanteIncompleto = Visitante.builder()
                .dni("40123123")
                .edad(28)
                .build();

        List<Visitante> visitantes = new ArrayList<>();
        visitantes.add(visitanteIncompleto);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("Los datos de uno o más visitantes están incompletos.", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_dni_visitante_nulo() {
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        Visitante visitanteSinDni = Visitante.builder()
                .nombreCompleto("Usuario Sin DNI")
                .edad(30)
                .build();

        List<Visitante> visitantes = new ArrayList<>();
        visitantes.add(visitanteSinDni);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("Los datos de uno o más visitantes están incompletos.", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_edad_visitante_nula() {
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        Visitante visitanteSinEdad = Visitante.builder()
                .nombreCompleto("Usuario Sin Edad")
                .dni("50123456")
                .build();

        List<Visitante> visitantes = new ArrayList<>();
        visitantes.add(visitanteSinEdad);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("Los datos de uno o más visitantes están incompletos.", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_nombre_con_numeros() {
        List<Visitante> visitantes = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        Visitante visitanteConNumero = Visitante.builder()
                .nombreCompleto("Lucia123 Sanchez")
                .dni("12345678")
                .edad(25)
                .build();
        visitantes.add(visitanteConNumero);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("El nombre del visitante solo puede contener letras.", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_dni_con_letras() {
        List<Visitante> visitantes = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        Visitante visitanteConLetraEnDNI = Visitante.builder()
                .nombreCompleto("Jorge Torres")
                .dni("1234567A")
                .edad(25)
                .build();
        visitantes.add(visitanteConLetraEnDNI);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("El DNI del visitante solo puede contener números.", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_edad_visitante_cero() {
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        Visitante visitanteConEdadCero = Visitante.builder()
                .nombreCompleto("Usuario Con Edad Cero")
                .dni("50123457")
                .edad(0)
                .build();

        List<Visitante> visitantes = new ArrayList<>();
        visitantes.add(visitanteConEdadCero);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("La edad no puede ser cero.", exception.getMessage());
    }

    // --- Pruebas para: validarDuplicadosDNI(List<Visitante> visitantes) ---

    @Test
    public void test_registrar_inscripcion_dni_duplicado() {
        List<Visitante> visitantes = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(2)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        Visitante visitante1 = Visitante.builder()
                .nombreCompleto("Elena Ruiz")
                .dni("12345678")
                .edad(25)
                .build();
        Visitante visitante2 = Visitante.builder()
                .nombreCompleto("Pedro Ramirez")
                .dni("12345678")
                .edad(30)
                .build();
        visitantes.add(visitante1);
        visitantes.add(visitante2);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("No puede haber visitantes con el mismo DNI en una inscripción.", exception.getMessage());
    }

    // --- Pruebas para: validarReglasDeNegocio(Actividad actividad, List<Visitante> visitantes) ---

    @Test
    public void test_registrar_inscripcion_supera_cupo_maximo() {
        List<Visitante> visitantesExcedidos = new ArrayList<>();
        char letra = 'A';
        for (int i = 0; i < 9; i++) {
            visitantesExcedidos.add(Visitante.builder()
                    .nombreCompleto("Visitante Letra " + (char)(letra + i))
                    .dni("3000000" + i)
                    .edad(20 + i)
                    .build());
        }
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(9)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();
        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantesExcedidos)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("La cantidad de visitantes supera el cupo para esta actividad", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_cuando_no_hay_cupos_disponibles() {
        // Primer grupo de 5 personas
        List<Visitante> primerGrupo = new ArrayList<>();
        primerGrupo.add(Visitante.builder()
                .nombreCompleto("Juan Perez")
                .dni("30000001")
                .edad(25)
                .build());
        primerGrupo.add(Visitante.builder()
                .nombreCompleto("Maria Garcia")
                .dni("30000002")
                .edad(25)
                .build());
        primerGrupo.add(Visitante.builder()
                .nombreCompleto("Pedro Rodriguez")
                .dni("30000003")
                .edad(25)
                .build());
        primerGrupo.add(Visitante.builder()
                .nombreCompleto("Ana Martinez")
                .dni("30000004")
                .edad(25)
                .build());
        primerGrupo.add(Visitante.builder()
                .nombreCompleto("Luis Sanchez")
                .dni("30000005")
                .edad(25)
                .build());

        Actividad primerActividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(5)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        InscripcionRequest primerRequest = InscripcionRequest.builder()
                .actividad(primerActividad)
                .visitantes(primerGrupo)
                .build();

        service.registrarInscripcion(primerRequest);

        // Segundo grupo de 4 personas
        List<Visitante> segundoGrupo = new ArrayList<>();
        segundoGrupo.add(Visitante.builder()
                .nombreCompleto("Carlos Lopez")
                .dni("40000001")
                .edad(25)
                .build());
        segundoGrupo.add(Visitante.builder()
                .nombreCompleto("Sofia Torres")
                .dni("40000002")
                .edad(25)
                .build());
        segundoGrupo.add(Visitante.builder()
                .nombreCompleto("Diego Ramirez")
                .dni("40000003")
                .edad(25)
                .build());
        segundoGrupo.add(Visitante.builder()
                .nombreCompleto("Laura Flores")
                .dni("40000004")
                .edad(25)
                .build());

        Actividad segundaActividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(4)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        InscripcionRequest segundoRequest = InscripcionRequest.builder()
                .actividad(segundaActividad)
                .visitantes(segundoGrupo)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(segundoRequest);
        });

        assertEquals("No hay cupos disponibles para el horario seleccionado", exception.getMessage());
    }

    @Test
    public void test_registrarInscripcion_cuandoHorarioNoEsValido() {
        String horarioInvalido = "18:00";
        List<Visitante> visitantes = new ArrayList<>();
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(horarioInvalido)
                .build();

        visitantes.add(Visitante.builder()
                .nombreCompleto("Ana Martinez")
                .dni("12345678")
                .edad(25)
                .build());

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("No se puede realizar una inscripción en el horario de cierre del parque", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_falta_talle_requerido() {
        Actividad actividadQueRequiereTalle = Actividad.builder()
                .tipoActividad(TipoActividad.TIROLESA)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_TIROLESA)
                .build();
        Visitante visitanteSinTalle = Visitante.builder()
                .nombreCompleto("Sofia Gomez")
                .dni("30123456")
                .edad(30)
                .talla("")
                .build();
        List<Visitante> visitantes = new ArrayList<>();
        visitantes.add(visitanteSinTalle);
        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividadQueRequiereTalle)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("Se debe ingresar un talle de ropa para esta actividad", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_edad_insuficiente_para_tirolesa() {
        Actividad actividad = Actividad.builder()
                .tipoActividad(TipoActividad.TIROLESA)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_TIROLESA)
                .build();

        Visitante visitanteMenor = Visitante.builder()
                .nombreCompleto("Matias Lopez")
                .dni("55123456")
                .edad(11)
                .talla("S")
                .build();

        List<Visitante> visitantes = new ArrayList<>();
        visitantes.add(visitanteMenor);

        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividad)
                .visitantes(visitantes)
                .build();

        IllegalArgumentException exception = assertThrows(IllegalArgumentException.class, () -> {
            service.registrarInscripcion(request);
        });

        assertEquals("La edad mínima para la actividad de Tirolesa es de 12 años.", exception.getMessage());
    }

    @Test
    public void test_registrar_inscripcion_con_talle_requerido() {
        Actividad actividadQueRequiereTalle = Actividad.builder()
                .tipoActividad(TipoActividad.TIROLESA)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_TIROLESA)
                .build();
        Visitante visitanteSinTalle = Visitante.builder()
                .nombreCompleto("Miguel Diaz")
                .dni("30123456")
                .edad(30)
                .talla("L")
                .build();
        List<Visitante> visitantes = new ArrayList<>();
        visitantes.add(visitanteSinTalle);
        InscripcionRequest request = InscripcionRequest.builder()
                .actividad(actividadQueRequiereTalle)
                .visitantes(visitantes)
                .build();

        InscripcionResponse response = service.registrarInscripcion(request);

        assertNotNull(response);
    }

    @Test
    public void test_registrar_inscripcion_diferentes_horarios_misma_actividad() {
        List<Visitante> primerGrupo = new ArrayList<>();
        primerGrupo.add(Visitante.builder()
                .nombreCompleto("Visitante Mañana")
                .dni("30000001")
                .edad(25)
                .build());

        Actividad primerActividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario(HORARIO_VALIDO_SAFARI)
                .build();

        InscripcionRequest primerRequest = InscripcionRequest.builder()
                .actividad(primerActividad)
                .visitantes(primerGrupo)
                .build();

        service.registrarInscripcion(primerRequest);

        List<Visitante> segundoGrupo = new ArrayList<>();
        segundoGrupo.add(Visitante.builder()
                .nombreCompleto("Visitante Tarde")
                .dni("30000002")
                .edad(25)
                .build());

        Actividad segundaActividad = Actividad.builder()
                .tipoActividad(TipoActividad.SAFARI)
                .TyC(true)
                .cantidadPersonas(1)
                .horario("11:00")
                .build();

        InscripcionRequest segundoRequest = InscripcionRequest.builder()
                .actividad(segundaActividad)
                .visitantes(segundoGrupo)
                .build();

        InscripcionResponse response = service.registrarInscripcion(segundoRequest);

        assertNotNull(response);
    }
}